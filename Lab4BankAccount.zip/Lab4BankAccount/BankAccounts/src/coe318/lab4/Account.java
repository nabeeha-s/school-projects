/**
 * @author Syeda Maryam Ali
 */

package coe318.lab4;

public class Account {
    
 /*instance variables*/
    private String name;
    private int number;
    private double balance;
    /*constructor*/
    public Account(String name, int number, double balance) {
        super();
        this.name = name;
        this.number = number;
        this.balance = balance;
    }
    public String getName() {   //returns name
        return name;
    }
    public int getNumber() {   //returns number
        return number;
    }
    public double getBalance() {   //returns balance
        return balance;
    }
    /*deposits and return success(true) or failure(false)*/        
    public boolean deposit(double amount) {
        if(amount<0 || amount==0)        //checks if amount is negative or zero    
            return false;
        this.balance+=amount;        //adds amount to the balance
        return true;
    }
    /*withdraws and return success(true) or failure(false)*/
    public boolean withdraw(double amount) {
        if(amount>balance || amount<0 || amount==0)        //checks if amount is negative or zero or greater than current balance
            return false;
        this.balance-=amount;        //deducts from balance
        return true;
    }
    @Override
    public String toString() {    //to print object in required manner
        return "(" + getName() + ", "+ getNumber() + ", " +String.format("$%.2f",getBalance())+ ")";
    }
 }